﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2_Khizirov_Ismail
{
    interface IFysiek
    {
        int AantalItems { get;}
    }
}