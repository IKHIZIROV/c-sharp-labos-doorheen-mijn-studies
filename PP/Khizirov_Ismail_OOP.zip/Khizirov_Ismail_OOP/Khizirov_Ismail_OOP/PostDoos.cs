﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Khizirov_Ismail_OOP
{
    class PostDoos : Doos
    {
        public int KostPrijs
        {
            get { return 10; }
        }
    }
}
