﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2_Khizirov_Ismail
{
    class Sample : MuziekItem
    {
        public Sample() : base("leukenaam",0)
        {
            
        }
    }
}
